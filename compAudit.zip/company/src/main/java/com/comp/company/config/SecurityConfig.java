//package com.comp.company;
//
//import org.springframework.context.annotation.Bean;
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
//import org.springframework.security.config.http.SessionCreationPolicy;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//import org.springframework.security.crypto.password.PasswordEncoder;
//import org.springframework.security.web.SecurityFilterChain;
//import org.springframework.security.web.util.matcher.RequestMatcher;
//import org.springframework.security.web.util.matcher.RequestMatchers;
//
//public class SecurityConfig {
//	
//	public SecurityFilterChain securityFilterChain(HttpSecurity security) throws Exception {
//		return security
//				.csrf(AbstractHttpConfigurer::disable)
//				.authorizeHttpRequests(req->req
//					.requestMatchers("/create")
//					.permitAll()
//					.anyRequest()
//					.authenticated()
//						)
//				.sessionManagement(session->session
//						.sessionCreationPolicy(SessionCreationPolicy.STATELESS)
//						)
//				.build();
//	}
//	
//	@Bean
//	public PasswordEncoder passwordEncoder() {
//		return new BCryptPasswordEncoder();
//	}
//
//}



