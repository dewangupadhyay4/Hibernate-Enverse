package com.comp.company.service;

import java.util.List;

import org.hibernate.envers.AuditReader;
import org.hibernate.envers.AuditReaderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.comp.company.entity.Employee;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

@Service
public class AuditService {
	
	@PersistenceContext
	public EntityManager entityManager;
	
	public List<Number> getRivisions(Integer id){
		AuditReader reader=AuditReaderFactory.get(entityManager);
		return reader.getRevisions(Employee.class, id);
	}
	
	public Employee getUserAtRevision(Integer id,Number revision) {
		AuditReader reader=AuditReaderFactory.get(entityManager);
		return reader.find(Employee.class, id,revision);
	}
	
	

}
