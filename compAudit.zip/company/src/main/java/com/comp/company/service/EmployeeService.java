package com.comp.company.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.comp.company.Exception.ResourceNotFoundException;
import com.comp.company.dto.EmployeeDto;
import com.comp.company.entity.Employee;
import com.comp.company.mapper.EmployeeMapper;
import com.comp.company.repository.EmployeeRepository;

@Service
public class EmployeeService {
	
	@Autowired
	private EmployeeRepository repo;
	
	@Autowired
	private EmployeeMapper mapper;

	public EmployeeDto create(EmployeeDto dto) {
		Employee emp=mapper.toDto(dto);
		Employee saved=repo.save(emp);
		
		return mapper.toEntity(saved);
	}

	public List<EmployeeDto> getOnce() {
		List<Employee> emp=repo.findAll();
		return mapper.toList(emp);
	}

	public EmployeeDto viaId(Integer id) {
		Employee emp=repo.findById(id).orElseThrow(()->new ResourceNotFoundException("Resource not found with ID: " + id));
		return mapper.toEntity(emp);
	}

	public EmployeeDto update(Integer id, EmployeeDto dto) {
		Employee emp=repo.findById(id).orElseThrow(()->new ResourceNotFoundException("Resource not found with ID: " + id));
		emp.setName(dto.getName());
		emp.setEmail(dto.getEmail());
		emp.setPassword(dto.getPassword());
		emp.setRole(dto.getRole());
		Employee saved=repo.save(emp);
		return mapper.toEntity(saved);
	}

	public EmployeeDto delete(Integer id) {
		repo.deleteById(id);
		return null;
	}

}
