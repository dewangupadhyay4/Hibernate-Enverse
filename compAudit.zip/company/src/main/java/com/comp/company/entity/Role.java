package com.comp.company.entity;

public enum Role {
	
	ADMIN,MEMBER;

}
