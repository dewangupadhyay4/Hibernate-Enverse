package com.comp.company.controller.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.AutoConfigureOrder;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.comp.company.controller.EmployeeController;
import com.comp.company.dto.EmployeeDto;
import com.comp.company.repository.EmployeeRepository;
import com.comp.company.service.EmployeeService;


@RestController
@RequestMapping("/api/v1/emps")
public class EmployeeControllerImpl implements EmployeeController{
	
	@Autowired
	private EmployeeService service;

	@Override
	@PostMapping("/create")
	public ResponseEntity<EmployeeDto> create(@RequestBody EmployeeDto dto) {
		EmployeeDto creation=service.create(dto);
		return new ResponseEntity<EmployeeDto>(creation,HttpStatus.CREATED);
	}

	@Override
	@GetMapping("/all")
	public ResponseEntity<List<EmployeeDto>> getAllOnce() {
		List<EmployeeDto> all=service.getOnce();
		return new ResponseEntity<List<EmployeeDto>>(all,HttpStatus.OK);
	}

	@Override
	@GetMapping("/all/{id}")
	public ResponseEntity<EmployeeDto> getViaId(@PathVariable Integer id) {
		EmployeeDto idd=service.viaId(id);
		return ResponseEntity.ok(idd);
	}

	@Override()
	@PutMapping("/update/{id}")
	public ResponseEntity<EmployeeDto> update(@PathVariable Integer id,@RequestBody EmployeeDto dto) {
		EmployeeDto up=service.update(id,dto);
		return ResponseEntity.ok(up);
	}

	@Override
	@GetMapping("/delete/{id}")
	public void delete(@PathVariable Integer id) {
		EmployeeDto del= service.delete(id);
		
	}

	
}
