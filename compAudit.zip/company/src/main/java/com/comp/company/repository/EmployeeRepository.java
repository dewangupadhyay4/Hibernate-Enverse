package com.comp.company.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.history.RevisionRepository;

import com.comp.company.entity.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Integer>{

}
